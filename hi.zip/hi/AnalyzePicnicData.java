package AnalyzingPicnicData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.io.*;



public class AnalyzePicnicData {
	public static void main(String[] args) throws Exception {

		sortByArea("west");//when user clicks on 'center' area

		String park = "Bartrams Garden";	//if the user selected this park
		parkSelected(park);

	}

	static void sortByArea(String areaWanted) throws Exception {
		Scanner sc = new Scanner(new File("picnicareas2 - Sheet1.csv"));

		String capitalAreaWanted = areaWanted.substring(0, 1).toUpperCase() + areaWanted.substring(1);
		System.out.println("Parks in " + capitalAreaWanted + " Philly:\n");

		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] parts = line.split(",");

			if (parts.length >= 2) {
				String parkName = parts[0].trim();
				String area = parts[1].trim();

				if (area.equals(areaWanted)) {
					System.out.println(parkName);
				}
			}
		}

	}
	
	
	static Map<String, List<String>> parkUsers = new HashMap<>();    
  
	static void addUserToPark(String park) {

		
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter your location: ");
        String location = scanner.nextLine();
        
        System.out.print("\nThanks for RSVPing! We'll see you there!\n");
		
		
		List<String> parkUserList = parkUsers.computeIfAbsent(park, k -> new ArrayList<>());

        parkUserList.add(name + " from " + location);

        
	
	}

	
	
	

	
	
	
	
	static int getNumPeople(String park,int numTables) throws Exception {
		int numPeople = 0;
		if (numTables == 0) {
			return numPeople;
		} else {
			numPeople = numTables * 8;
		}					
		return numPeople; 
	}

	static void parkSelected(String park) throws Exception {
		Scanner sc = new Scanner(new File("ppr_picnic_sites.csv"));
		Scanner sc2 = new Scanner(new File("picnicareas2 - Sheet1.csv"));

		boolean cont = true;
        
        while(cont) {
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] parts = line.split(",");

			String line2 = sc2.nextLine();
			String[] parts2 = line2.split(",");

			if (parts.length >= 2 && parts2.length >= 2) {
				String parkName = parts[1].trim();

				
				String numTablesStr = parts[3].trim();
				int numTables = 0;
				if (!numTablesStr.isEmpty() && !numTablesStr.equalsIgnoreCase("table_count")) {
					try { numTables = Integer.parseInt(numTablesStr);
				} catch (NumberFormatException e) {} 
				}
					
		
				
				
				
				
				String comments;
				if (parts[4].isEmpty()) {
					comments = "N/A";
				} else {
					comments = parts[4].trim();
				}

				// String lat = parts[6].trim();
				// String lng = parts[7].trim();

				String area = parts2[1].trim();


				if (parkName.equals(park)) {
					
					

					String capitalArea = area.substring(0, 1).toUpperCase() + area.substring(1);
					System.out.println("\nPicnic place name: " + parkName);
					System.out.println("Region: " + capitalArea + " Philly");
					System.out.println("Additional comments: " + comments);
					System.out.println("Number of tables: " + numTables);
					if (getNumPeople(park,numTables) > 0) {
						System.out.println("Maximum number of people: " + getNumPeople(park,numTables));
					} else {
						System.out.println("Maximum number of people: Information unavailable");
					}
					
					
					
					

					System.out.println("\nRSVP Information for " + park + ":");

			        List<String> parkUserList = parkUsers.get(park);
			        if (parkUserList != null) {
			            for (String userData : parkUserList) {
			                System.out.println(userData);
			            }
			        }
			        else {
			        	System.out.println("No one has RSVPed for this picnic yet!");
			        }
			        
			        
			        Scanner scanner = new Scanner(System.in);
			        System.out.print("\nWould you like to RSVP? Enter Y or N: ");
			        String choice = scanner.nextLine();
			        if (choice.equals("Y")) {
			        	addUserToPark(park);
			        }
			        
			        System.out.print("\nDo you want to continue? Enter Y or N: ");
		            String contChoice = scanner.nextLine();

		            if (contChoice.equals("N")) {
		                cont = false;
		                break;
		            }
			        
				}
			}
		}
        }

	}

}
