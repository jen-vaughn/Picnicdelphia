package com.example.hi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sublocationFinal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sublocation_final);


        Button foodButton;
        foodButton = (Button) findViewById(R.id.specificPark);

        foodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                food();
            }
        });
    }



    public void food() {
        Intent intent = new Intent(this, food.class);
        startActivity(intent);
    }



}