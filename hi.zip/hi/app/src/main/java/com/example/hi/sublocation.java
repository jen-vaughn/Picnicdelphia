package com.example.hi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sublocation extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        Button specificParkButton;
        specificParkButton = (Button) findViewById(R.id.specificPark);

        specificParkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                specificPark();
            }
        });
    }

    public void specificPark() {
        Intent intent = new Intent(this, locationPage.class);
        startActivity(intent);
    }

}
