package com.example.hi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NewActivity extends AppCompatActivity {

    Button button, buttonlocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        button = (Button) findViewById(R.id.button2);
        buttonlocation = (Button) findViewById(R.id.locationButton);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Activitybutton1();
            }
        });



        buttonlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationButton();
            }
        });
    }

    public void Activitybutton1() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void locationButton() {
        Intent intent = new Intent(this, locationPage.class);
        startActivity(intent);
    }



}